from django.shortcuts import render, redirect

import nltk

from core.constants import GITHUB_URL

def default_view(request):
	return redirect(GITHUB_URL)
