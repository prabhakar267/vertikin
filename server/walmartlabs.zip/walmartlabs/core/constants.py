# -*- coding: utf-8 -*-
# @Author: prabhakar
# @Date:   2016-08-17 21:51:24
# @Last Modified by:   Prabhakar Gupta
# @Last Modified time: 2016-08-17 21:51:40

GITHUB_URL = "https://github.com/prabhakar267/Walmart-hackathon-ki-entry"