# -*- coding: utf-8 -*-
# @Author: prabhakar
# @Date:   2016-08-17 21:24:22
# @Last Modified by:   Prabhakar Gupta
# @Last Modified time: 2016-08-17 21:57:50

from django.conf.urls import patterns, url
from django.contrib.staticfiles.urls import staticfiles_urlpatterns


urlpatterns = patterns('',
    url(r'^$',
        'core.views.default_view',
        name='default_view'),
    url(r'^$user',
        'core.views.get_user_id',
        name='get_user_id'),
)


urlpatterns += staticfiles_urlpatterns()
